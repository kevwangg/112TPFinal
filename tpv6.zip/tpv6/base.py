#Calls the runStartPage function when the game is launched 
#so that any future returns to the start page will 
#not create a circular import and crash the game

import startpage

def start():
    startpage.runStartPage()

start()
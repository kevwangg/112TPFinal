#Draws the game board

import tkinter
from cmu_112_graphics import *

#This is the function that creates the map as an image
#so there is no lag each time redrawAll is called
def drawBoardTwo(app, canvas):
    canvas.create_image(app.width//2, app.height//2, image=ImageTk.PhotoImage(app.fullMapScaled))

